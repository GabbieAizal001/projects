from flask import Flask, render_template, request, redirect, url_for, flash
import random
import string




app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session and flash messages

# To store user data, we will use a simple dictionary (this could be a database in production)
users_db = {}

def generate_user_id():
    """Generate a random user ID consisting of letters and digits."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=8))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/open_account', methods=['POST'])
def open_account():
    customer_name = request.form.get('customer_name')
    if customer_name:
        user_id = generate_user_id()
        # Store the user in the database (simulated with a dictionary)
        users_db[user_id] = {'name': customer_name, 'balance': 0, 'transactions': []}
        flash(f'Account opened successfully! User ID: {user_id}')
    return redirect(url_for('index'))

@app.route('/deposit', methods=['POST'])
def deposit():
    customer_name = request.form.get('customer_name')
    account_number = request.form.get('account_number')
    amount = float(request.form.get('amount'))
    
    # Check if account exists
    if account_number in users_db and users_db[account_number]['name'] == customer_name:
        users_db[account_number]['balance'] += amount
        users_db[account_number]['transactions'].append(f"Deposited {amount} GHS")
        flash(f"Deposited {amount} GHS to account {account_number}")
    else:
        flash("Invalid account or customer name.")
    return redirect(url_for('index'))

@app.route('/withdraw', methods=['POST'])
def withdraw():
    customer_name = request.form.get('customer_name')
    account_number = request.form.get('account_number')
    amount = float(request.form.get('amount'))
    
    # Check if account exists and has sufficient balance
    if account_number in users_db and users_db[account_number]['name'] == customer_name:
        if users_db[account_number]['balance'] >= amount:
            users_db[account_number]['balance'] -= amount
            users_db[account_number]['transactions'].append(f"Withdrew {amount} GHS")
            flash(f"Withdrew {amount} GHS from account {account_number}")
        else:
            flash("Insufficient balance.")
    else:
        flash("Invalid account or customer name.")
    return redirect(url_for('index'))

@app.route('/balance', methods=['POST'])
def check_balance():
    customer_name = request.form.get('customer_name')
    account_number = request.form.get('account_number')
    
    # Check if account exists
    if account_number in users_db and users_db[account_number]['name'] == customer_name:
        balance = users_db[account_number]['balance']
        flash(f"Account balance for {account_number}: {balance} GHS")
    else:
        flash("Invalid account or customer name.")
    return redirect(url_for('index'))

@app.route('/transaction_history', methods=['POST'])
def transaction_history():
    customer_name = request.form.get('customer_name')
    account_number = request.form.get('account_number')
    
    # Check if account exists
    if account_number in users_db and users_db[account_number]['name'] == customer_name:
        transactions = users_db[account_number]['transactions']
        flash(f"Transaction History for {account_number}: {'; '.join(transactions)}")
    else:
        flash("Invalid account or customer name.")
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
